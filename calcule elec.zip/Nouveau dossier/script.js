function resetFields() {
  document.querySelectorAll('input').forEach(el => {
    el.value = '';
    el.classList.remove('error');
  });
  document.getElementById('result').innerHTML = '';
}

function calculate() {
  const phaseType = document.getElementById('phaseType').value;
  const V = parseFloat(document.getElementById('voltage').value);
  const P = parseFloat(document.getElementById('power').value);
  let current = parseFloat(document.getElementById('current').value);
  let L = parseFloat(document.getElementById('length').value);
  const rho = parseFloat(document.getElementById('material').value);
  const usage = document.getElementById('usage').value;
  const sectionInput = parseFloat(document.getElementById('section').value);

  const deltaPercent = (usage === "إضاءة") ? 3 : 5;
  const deltaU = (V * deltaPercent) / 100;
  let section = (!isNaN(sectionInput) && sectionInput > 0) ? sectionInput : null;

  if (isNaN(V) || (isNaN(P) && isNaN(current)) || isNaN(rho) || isNaN(L)) {
    alert('⚠️ الرجاء إدخال جميع القيم المطلوبة بشكل صحيح.');
    return;
  }

  let totalP = P || (phaseType === 'three' ? Math.sqrt(3) * V * current : V * current);
  current = current || (phaseType === 'three' ? P / (Math.sqrt(3) * V) : P / V);

  if (section && current) {
    L = (deltaU * section) / (2 * rho * current);
  }

  if ((!section || isNaN(section)) && current && L) {
    section = (2 * rho * L * current) / deltaU;
  }

  const availableSections = [1.5, 2.5, 4, 6, 10, 16, 25, 35, 50, 70, 95, 120];
  const roundedSection = availableSections.find(s => section <= s) || availableSections[availableSections.length - 1];
  const Umin = V - deltaU;

  const resultHTML = `
    <strong>نوع النظام:</strong> ${phaseType === 'three' ? 'ثلاثي الطور' : 'أحادي الطور'}<br>
    <strong>٪ نسبة هبوط الجهد المسموحة:</strong> ${deltaPercent}%<br>
    <strong>الجهد بعد الهبوط:</strong> ${Umin.toFixed(2)} V<br>
    <strong>ΔU التوتر المفقود:</strong> ${deltaU.toFixed(2)} V<br>
    <strong>شدة التيار:</strong> ${current.toFixed(2)} A<br>
    <strong>الاستطاعة الكلية:</strong> ${totalP.toFixed(2)} W<br>
    <strong>القاطع المناسب:</strong> ${getBreaker(current)} A<br>
    <strong>🧮 المقطع الحقيقي المحسوب:</strong> ${section.toFixed(2)} مم²<br>
    <strong>✅ المقطع الموصى به:</strong> ${roundedSection} مم²<br>
    <strong>📏 طول السلك المعتمد:</strong> ${Math.round(L)} متر
  `;

  document.getElementById('result').innerHTML = resultHTML;
}

function getBreaker(current) {
  const breakers = [10, 16, 25, 32, 45, 50, 63, 125];
  return breakers.find(b => current <= b) || breakers[breakers.length - 1];
}

async function downloadPDF() {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  const resultText = document.getElementById("result").innerText;
  doc.text(resultText, 10, 10, { maxWidth: 180 });
  doc.save("circuit_calculation.pdf");
}
